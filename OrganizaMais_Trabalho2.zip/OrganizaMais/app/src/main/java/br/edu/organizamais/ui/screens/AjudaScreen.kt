package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.edu.organizamais.ui.components.CabecalhoSecao

@Composable
fun AjudaScreen(abrirSobre: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        CabecalhoSecao("Guia rápido", "Conheça as principais funções disponíveis no aplicativo.")
        listOf(
            "1. Criar projetos" to "Abra a aba Projetos e pressione +. Informe o nome, uma descrição opcional e uma cor.",
            "2. Adicionar tarefas" to "Na aba Tarefas, pressione +, preencha o título e selecione a prioridade e o projeto associado.",
            "3. Concluir atividades" to "Marque a caixa ao lado de cada tarefa. O progresso do projeto e do painel será atualizado.",
            "4. Consultar detalhes" to "Toque em uma tarefa ou projeto para visualizar informações reais, editar os dados ou remover o item.",
            "5. Acompanhar o desempenho" to "Abra a aba Resumo e veja a quantidade de tarefas pendentes, concluídas e o progresso de cada projeto.",
            "6. Navegar" to "Use a barra inferior para alternar entre as áreas principais e a seta superior para retornar aos detalhes anteriores."
        ).forEach { (titulo, texto) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(titulo, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                    Text(texto)
                }
            }
        }
        OutlinedButton(onClick = abrirSobre, modifier = Modifier.fillMaxWidth()) { Text("Sobre o Organiza+") }
    }
}
