package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.model.Tarefa
import br.edu.organizamais.ui.components.CabecalhoSecao
import br.edu.organizamais.ui.components.ConfirmarRemocao
import br.edu.organizamais.ui.components.EstadoVazio

@Composable
fun TarefasScreen(state: OrganizaState, abrirDetalhe: (Int) -> Unit) {
    var mostrarFormulario by remember { mutableStateOf(false) }
    var removerId by remember { mutableStateOf<Int?>(null) }
    var somentePendentes by remember { mutableStateOf(false) }
    val visiveis = state.tarefas.filter { !somentePendentes || !it.concluida }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { CabecalhoSecao("Suas atividades", "Adicione, conclua, remova ou abra uma tarefa para editá-la.") }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = somentePendentes, onCheckedChange = { somentePendentes = it })
                    Text("Mostrar apenas pendentes")
                }
            }
            if (visiveis.isEmpty()) {
                item { EstadoVazio("Nenhuma tarefa encontrada. Use o botão + para adicionar uma.") }
            }
            items(visiveis, key = { it.id }) { tarefa ->
                Card(onClick = { abrirDetalhe(tarefa.id) }, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = tarefa.concluida,
                            onCheckedChange = { state.alternarConcluida(tarefa.id) }
                        )
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(
                                tarefa.titulo,
                                fontWeight = FontWeight.SemiBold,
                                textDecoration = if (tarefa.concluida) TextDecoration.LineThrough else null,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text("${tarefa.prioridade} • ${state.projetoDe(tarefa.projetoId)?.nome ?: "Sem projeto"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { removerId = tarefa.id }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Remover tarefa ${tarefa.titulo}")
                        }
                    }
                }
            }
            item { androidx.compose.foundation.layout.Spacer(Modifier.padding(bottom = 72.dp)) }
        }
        FloatingActionButton(
            onClick = { mostrarFormulario = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Filled.Add, contentDescription = "Adicionar tarefa") }
    }

    if (mostrarFormulario) {
        FormularioTarefa(
            state = state,
            tarefa = null,
            aoSalvar = { titulo, descricao, projetoId, prioridade ->
                if (state.adicionarTarefa(titulo, descricao, projetoId, prioridade)) mostrarFormulario = false
            },
            aoCancelar = { mostrarFormulario = false }
        )
    }

    val tarefaRemover = state.tarefas.firstOrNull { it.id == removerId }
    if (tarefaRemover != null) {
        ConfirmarRemocao(
            objeto = "tarefa",
            mensagem = "A tarefa ${tarefaRemover.titulo} será removida da lista.",
            aoConfirmar = {
                state.removerTarefa(tarefaRemover.id)
                removerId = null
            },
            aoCancelar = { removerId = null }
        )
    }
}

@Composable
fun FormularioTarefa(
    state: OrganizaState,
    tarefa: Tarefa?,
    aoSalvar: (String, String, Int?, String) -> Unit,
    aoCancelar: () -> Unit
) {
    var titulo by remember(tarefa?.id) { mutableStateOf(tarefa?.titulo.orEmpty()) }
    var descricao by remember(tarefa?.id) { mutableStateOf(tarefa?.descricao.orEmpty()) }
    var projetoId by remember(tarefa?.id) { mutableStateOf(tarefa?.projetoId) }
    var prioridade by remember(tarefa?.id) { mutableStateOf(tarefa?.prioridade ?: "Média") }
    var mostrarProjetos by remember { mutableStateOf(false) }
    var mostrarPrioridades by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = aoCancelar,
        title = { Text(if (tarefa == null) "Nova tarefa" else "Editar tarefa") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 490.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Título da tarefa") },
                    singleLine = true,
                    isError = titulo.isBlank(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = descricao,
                    onValueChange = { descricao = it },
                    label = { Text("Descrição") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Box {
                    OutlinedButton(onClick = { mostrarProjetos = true }) {
                        Text("Projeto: ${state.projetoDe(projetoId)?.nome ?: "Sem projeto"}")
                    }
                    DropdownMenu(expanded = mostrarProjetos, onDismissRequest = { mostrarProjetos = false }) {
                        DropdownMenuItem(text = { Text("Sem projeto") }, onClick = {
                            projetoId = null
                            mostrarProjetos = false
                        })
                        state.projetos.forEach { projeto ->
                            DropdownMenuItem(text = { Text(projeto.nome) }, onClick = {
                                projetoId = projeto.id
                                mostrarProjetos = false
                            })
                        }
                    }
                }
                Box {
                    OutlinedButton(onClick = { mostrarPrioridades = true }) { Text("Prioridade: $prioridade") }
                    DropdownMenu(expanded = mostrarPrioridades, onDismissRequest = { mostrarPrioridades = false }) {
                        listOf("Baixa", "Média", "Alta").forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = {
                                prioridade = item
                                mostrarPrioridades = false
                            })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = titulo.isNotBlank(), onClick = { aoSalvar(titulo, descricao, projetoId, prioridade) }) {
                Text("Salvar")
            }
        },
        dismissButton = { TextButton(onClick = aoCancelar) { Text("Cancelar") } }
    )
}
