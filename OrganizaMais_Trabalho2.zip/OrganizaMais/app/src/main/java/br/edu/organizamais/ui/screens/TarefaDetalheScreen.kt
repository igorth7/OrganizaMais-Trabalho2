package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Row
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.ui.components.CampoInformacao
import br.edu.organizamais.ui.components.ConfirmarRemocao
import br.edu.organizamais.ui.components.EstadoVazio
import br.edu.organizamais.ui.components.GrupoBotoes

@Composable
fun TarefaDetalheScreen(
    state: OrganizaState,
    id: Int,
    voltar: () -> Unit,
    abrirProjeto: (Int) -> Unit
) {
    val tarefa = state.tarefas.firstOrNull { it.id == id }
    var editando by remember { mutableStateOf(false) }
    var confirmandoRemocao by remember { mutableStateOf(false) }

    if (tarefa == null) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            EstadoVazio("Esta tarefa não está mais disponível.")
            OutlinedButton(onClick = voltar) { Text("Voltar") }
        }
        return
    }

    val projeto = state.projetoDe(tarefa.projetoId)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(tarefa.titulo, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                CampoInformacao("Descrição", tarefa.descricao)
                CampoInformacao("Prioridade", tarefa.prioridade)
                CampoInformacao("Projeto associado", projeto?.nome ?: "Sem projeto")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = tarefa.concluida, onCheckedChange = { state.alternarConcluida(id) })
                    Text(if (tarefa.concluida) "Tarefa concluída" else "Tarefa pendente")
                }
            }
        }
        if (projeto != null) {
            OutlinedButton(onClick = { abrirProjeto(projeto.id) }, modifier = Modifier.fillMaxWidth()) {
                Text("Ver projeto: ${projeto.nome}")
            }
        }
        GrupoBotoes(
            textoPrincipal = "Editar tarefa",
            acaoPrincipal = { editando = true },
            textoSecundario = "Remover",
            acaoSecundaria = { confirmandoRemocao = true }
        )
    }

    if (editando) {
        FormularioTarefa(
            state = state,
            tarefa = tarefa,
            aoSalvar = { titulo, descricao, projetoId, prioridade ->
                if (state.atualizarTarefa(id, titulo, descricao, projetoId, prioridade)) editando = false
            },
            aoCancelar = { editando = false }
        )
    }

    if (confirmandoRemocao) {
        ConfirmarRemocao(
            objeto = "tarefa",
            mensagem = "Esta tarefa será excluída da lista.",
            aoConfirmar = {
                state.removerTarefa(id)
                confirmandoRemocao = false
                voltar()
            },
            aoCancelar = { confirmandoRemocao = false }
        )
    }
}
