package br.edu.organizamais.model

data class Projeto(
    val id: Int,
    val nome: String,
    val descricao: String,
    val cor: String = "Azul"
)

data class Tarefa(
    val id: Int,
    val titulo: String,
    val descricao: String,
    val projetoId: Int?,
    val prioridade: String,
    val concluida: Boolean = false
)
