package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.ui.components.CabecalhoSecao
import br.edu.organizamais.ui.components.CampoInformacao
import br.edu.organizamais.ui.components.ConfirmarRemocao
import br.edu.organizamais.ui.components.EstadoVazio
import br.edu.organizamais.ui.components.GrupoBotoes

@Composable
fun ProjetoDetalheScreen(
    state: OrganizaState,
    id: Int,
    voltar: () -> Unit,
    abrirTarefa: (Int) -> Unit
) {
    val projeto = state.projetos.firstOrNull { it.id == id }
    var editando by remember { mutableStateOf(false) }
    var confirmandoRemocao by remember { mutableStateOf(false) }

    if (projeto == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) { EstadoVazio("Este projeto não está mais disponível.") }
        return
    }

    val tarefas = state.tarefasDoProjeto(id)
    val concluidas = tarefas.count { it.concluida }
    val progresso = if (tarefas.isEmpty()) 0f else concluidas.toFloat() / tarefas.size

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(projeto.nome, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    CampoInformacao("Descrição", projeto.descricao)
                    CampoInformacao("Identificação visual", projeto.cor)
                    CampoInformacao("Atividades", "${tarefas.size} no total • $concluidas concluída(s)")
                    val percentual = (progresso * 100).toInt()
                    Text("Conclusão do projeto: $percentual%", fontWeight = FontWeight.SemiBold)
                    LinearProgressIndicator(progress = { progresso }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        item {
            GrupoBotoes(
                textoPrincipal = "Editar projeto",
                acaoPrincipal = { editando = true },
                textoSecundario = "Remover",
                acaoSecundaria = { confirmandoRemocao = true }
            )
        }
        item {
            CabecalhoSecao("Tarefas vinculadas", "Toque em uma atividade para abrir seus detalhes.")
        }
        if (tarefas.isEmpty()) {
            item { EstadoVazio("Não há tarefas associadas a este projeto.") }
        }
        items(tarefas, key = { it.id }) { tarefa ->
            Card(onClick = { abrirTarefa(tarefa.id) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(tarefa.titulo, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${tarefa.prioridade} • ${if (tarefa.concluida) "Concluída" else "Pendente"}",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }

    if (editando) {
        FormularioProjeto(
            projeto = projeto,
            aoSalvar = { nome, descricao, cor ->
                if (state.atualizarProjeto(id, nome, descricao, cor)) editando = false
            },
            aoCancelar = { editando = false }
        )
    }

    if (confirmandoRemocao) {
        ConfirmarRemocao(
            objeto = "projeto",
            mensagem = "As tarefas associadas serão mantidas sem vínculo com o projeto.",
            aoConfirmar = {
                state.removerProjeto(id)
                confirmandoRemocao = false
                voltar()
            },
            aoCancelar = { confirmandoRemocao = false }
        )
    }
}
