package br.edu.organizamais.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.ui.screens.AjudaScreen
import br.edu.organizamais.ui.screens.InicioScreen
import br.edu.organizamais.ui.screens.ProjetoDetalheScreen
import br.edu.organizamais.ui.screens.ProjetosScreen
import br.edu.organizamais.ui.screens.ResumoScreen
import br.edu.organizamais.ui.screens.SobreScreen
import br.edu.organizamais.ui.screens.TarefaDetalheScreen
import br.edu.organizamais.ui.screens.TarefasScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(state: OrganizaState) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val rotaAtual = backStack?.destination?.route ?: Routes.Inicio
    val abas = listOf(Routes.Inicio, Routes.Tarefas, Routes.Projetos, Routes.Resumo)
    val titulo = when (rotaAtual) {
        Routes.Inicio -> "Organiza+"
        Routes.Tarefas -> "Minhas tarefas"
        Routes.Projetos -> "Meus projetos"
        Routes.Resumo -> "Resumo"
        Routes.DetalheTarefa -> "Detalhes da tarefa"
        Routes.DetalheProjeto -> "Detalhes do projeto"
        Routes.Ajuda -> "Como utilizar"
        Routes.Sobre -> "Sobre o aplicativo"
        else -> "Organiza+"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(titulo) },
                navigationIcon = {
                    if (rotaAtual !in abas) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                        }
                    }
                },
                actions = {
                    if (rotaAtual == Routes.Inicio) {
                        IconButton(onClick = { navController.navigate(Routes.Ajuda) }) {
                            Icon(Icons.Filled.HelpOutline, contentDescription = "Ajuda")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val opcoes = listOf(
                    Triple(Routes.Inicio, "Início", Icons.Filled.Home),
                    Triple(Routes.Tarefas, "Tarefas", Icons.Filled.Assignment),
                    Triple(Routes.Projetos, "Projetos", Icons.Filled.Folder),
                    Triple(Routes.Resumo, "Resumo", Icons.Filled.Insights)
                )
                opcoes.forEach { (rota, nome, icone) ->
                    NavigationBarItem(
                        selected = rotaAtual == rota,
                        onClick = {
                            navController.navigate(rota) {
                                popUpTo(Routes.Inicio) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icone, contentDescription = nome) },
                        label = { Text(nome) }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Routes.Inicio,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(Routes.Inicio) {
                InicioScreen(
                    state = state,
                    abrirTarefas = { navController.navigate(Routes.Tarefas) },
                    abrirProjetos = { navController.navigate(Routes.Projetos) },
                    abrirResumo = { navController.navigate(Routes.Resumo) },
                    abrirAjuda = { navController.navigate(Routes.Ajuda) }
                )
            }
            composable(Routes.Tarefas) {
                TarefasScreen(state = state, abrirDetalhe = { navController.navigate(Routes.tarefa(it)) })
            }
            composable(Routes.Projetos) {
                ProjetosScreen(state = state, abrirDetalhe = { navController.navigate(Routes.projeto(it)) })
            }
            composable(Routes.Resumo) { ResumoScreen(state = state) }
            composable(Routes.DetalheTarefa, arguments = listOf(navArgument("id") { type = NavType.IntType })) { entry ->
                val id = entry.arguments?.getInt("id") ?: -1
                TarefaDetalheScreen(state = state, id = id, voltar = { navController.popBackStack() }, abrirProjeto = {
                    navController.navigate(Routes.projeto(it))
                })
            }
            composable(Routes.DetalheProjeto, arguments = listOf(navArgument("id") { type = NavType.IntType })) { entry ->
                val id = entry.arguments?.getInt("id") ?: -1
                ProjetoDetalheScreen(state = state, id = id, voltar = { navController.popBackStack() }, abrirTarefa = {
                    navController.navigate(Routes.tarefa(it))
                })
            }
            composable(Routes.Ajuda) {
                AjudaScreen(abrirSobre = { navController.navigate(Routes.Sobre) })
            }
            composable(Routes.Sobre) { SobreScreen() }
        }
    }
}
