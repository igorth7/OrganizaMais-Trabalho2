package br.edu.organizamais.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CabecalhoSecao(titulo: String, descricao: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(titulo, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (descricao != null) Text(descricao, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun CartaoMetrica(nome: String, valor: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(valor, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(nome, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun EstadoVazio(mensagem: String) {
    Card(Modifier.fillMaxWidth()) {
        Text(
            mensagem,
            modifier = Modifier.padding(24.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CampoInformacao(rotulo: String, conteudo: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(rotulo, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(conteudo.ifBlank { "Não informado" }, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun ConfirmarRemocao(
    objeto: String,
    mensagem: String,
    aoConfirmar: () -> Unit,
    aoCancelar: () -> Unit
) {
    AlertDialog(
        onDismissRequest = aoCancelar,
        title = { Text("Remover $objeto?") },
        text = { Text(mensagem) },
        confirmButton = { Button(onClick = aoConfirmar) { Text("Remover") } },
        dismissButton = { TextButton(onClick = aoCancelar) { Text("Cancelar") } }
    )
}

@Composable
fun GrupoBotoes(
    textoPrincipal: String,
    acaoPrincipal: () -> Unit,
    textoSecundario: String,
    acaoSecundaria: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = acaoPrincipal, modifier = Modifier.weight(1f)) { Text(textoPrincipal) }
        OutlinedButton(onClick = acaoSecundaria, modifier = Modifier.weight(1f)) { Text(textoSecundario) }
    }
}
