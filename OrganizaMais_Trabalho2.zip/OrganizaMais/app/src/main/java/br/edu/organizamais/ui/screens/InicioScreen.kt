package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.ui.components.CabecalhoSecao
import br.edu.organizamais.ui.components.CartaoMetrica

@Composable
fun InicioScreen(
    state: OrganizaState,
    abrirTarefas: () -> Unit,
    abrirProjetos: () -> Unit,
    abrirResumo: () -> Unit,
    abrirAjuda: () -> Unit
) {
    val concluidas = state.tarefas.count { it.concluida }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        CabecalhoSecao("Tudo em um só lugar", "Organize suas tarefas, projetos e acompanhe seu progresso.")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoMetrica("Tarefas", state.tarefas.size.toString(), Modifier.weight(1f))
            CartaoMetrica("Concluídas", concluidas.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoMetrica("Projetos", state.projetos.size.toString(), Modifier.weight(1f))
            val percentual = if (state.tarefas.isEmpty()) 0 else concluidas * 100 / state.tarefas.size
            CartaoMetrica("Progresso", "$percentual%", Modifier.weight(1f))
        }
        CabecalhoSecao("Acesso rápido")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Gerencie suas atividades", fontWeight = FontWeight.SemiBold)
                Text("Crie tarefas, marque as concluídas e abra os detalhes de cada uma.")
                Button(onClick = abrirTarefas, modifier = Modifier.fillMaxWidth()) {
                    Text("Abrir tarefas")
                    Icon(Icons.Filled.ArrowForward, contentDescription = null, Modifier.padding(start = 8.dp))
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Organize seus projetos", fontWeight = FontWeight.SemiBold)
                Text("Associe tarefas aos projetos e visualize os resultados de cada um.")
                Button(onClick = abrirProjetos, modifier = Modifier.fillMaxWidth()) { Text("Abrir projetos") }
            }
        }
        Button(onClick = abrirResumo, modifier = Modifier.fillMaxWidth()) { Text("Ver painel de resultados") }
        OutlinedButton(onClick = abrirAjuda, modifier = Modifier.fillMaxWidth()) { Text("Como usar o aplicativo") }
        Text("As alterações são mantidas enquanto o aplicativo está aberto.", style = MaterialTheme.typography.bodySmall)
    }
}
