package br.edu.organizamais.model

import androidx.compose.runtime.mutableStateListOf

class OrganizaState {
    val projetos = mutableStateListOf(
        Projeto(1, "Faculdade", "Atividades, provas e entregas acadêmicas", "Azul"),
        Projeto(2, "Pessoal", "Compromissos e organização do dia a dia", "Verde")
    )

    val tarefas = mutableStateListOf(
        Tarefa(1, "Revisar Kotlin", "Estudar funções, classes e listas", 1, "Alta"),
        Tarefa(2, "Finalizar apresentação", "Conferir os slides antes da entrega", 1, "Média"),
        Tarefa(3, "Organizar rotina", "Planejar as atividades da semana", 2, "Baixa", true)
    )

    private var proximoProjetoId = 3
    private var proximaTarefaId = 4

    fun adicionarProjeto(nome: String, descricao: String, cor: String): Boolean {
        if (nome.isBlank()) return false
        projetos.add(Projeto(proximoProjetoId++, nome.trim(), descricao.trim(), cor))
        return true
    }

    fun atualizarProjeto(id: Int, nome: String, descricao: String, cor: String): Boolean {
        if (nome.isBlank()) return false
        val index = projetos.indexOfFirst { it.id == id }
        if (index < 0) return false
        projetos[index] = projetos[index].copy(nome = nome.trim(), descricao = descricao.trim(), cor = cor)
        return true
    }

    fun removerProjeto(id: Int) {
        projetos.removeAll { it.id == id }
        tarefas.indices.forEach { index ->
            if (tarefas[index].projetoId == id) {
                tarefas[index] = tarefas[index].copy(projetoId = null)
            }
        }
    }

    fun adicionarTarefa(titulo: String, descricao: String, projetoId: Int?, prioridade: String): Boolean {
        if (titulo.isBlank()) return false
        if (projetoId != null && projetos.none { it.id == projetoId }) return false
        tarefas.add(Tarefa(proximaTarefaId++, titulo.trim(), descricao.trim(), projetoId, prioridade))
        return true
    }

    fun atualizarTarefa(
        id: Int,
        titulo: String,
        descricao: String,
        projetoId: Int?,
        prioridade: String
    ): Boolean {
        if (titulo.isBlank()) return false
        if (projetoId != null && projetos.none { it.id == projetoId }) return false
        val index = tarefas.indexOfFirst { it.id == id }
        if (index < 0) return false
        tarefas[index] = tarefas[index].copy(
            titulo = titulo.trim(),
            descricao = descricao.trim(),
            projetoId = projetoId,
            prioridade = prioridade
        )
        return true
    }

    fun alternarConcluida(id: Int) {
        val index = tarefas.indexOfFirst { it.id == id }
        if (index >= 0) tarefas[index] = tarefas[index].copy(concluida = !tarefas[index].concluida)
    }

    fun removerTarefa(id: Int) {
        tarefas.removeAll { it.id == id }
    }

    fun projetoDe(id: Int?): Projeto? = projetos.firstOrNull { it.id == id }
    fun tarefasDoProjeto(id: Int): List<Tarefa> = tarefas.filter { it.projetoId == id }
}
