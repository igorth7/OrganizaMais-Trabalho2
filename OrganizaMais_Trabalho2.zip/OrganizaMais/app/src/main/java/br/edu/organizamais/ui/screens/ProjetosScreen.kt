package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.model.Projeto
import br.edu.organizamais.ui.components.CabecalhoSecao
import br.edu.organizamais.ui.components.ConfirmarRemocao
import br.edu.organizamais.ui.components.EstadoVazio

@Composable
fun ProjetosScreen(state: OrganizaState, abrirDetalhe: (Int) -> Unit) {
    var mostrarFormulario by remember { mutableStateOf(false) }
    var removerId by remember { mutableStateOf<Int?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                CabecalhoSecao("Projetos em andamento", "Toque em um projeto para consultar os detalhes e as tarefas vinculadas.")
            }
            if (state.projetos.isEmpty()) {
                item { EstadoVazio("Nenhum projeto cadastrado. Use o botão + para criar o primeiro.") }
            }
            items(state.projetos, key = { it.id }) { projeto ->
                Card(onClick = { abrirDetalhe(projeto.id) }, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(projeto.nome, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(projeto.descricao.ifBlank { "Sem descrição" }, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            val quantidade = state.tarefasDoProjeto(projeto.id).size
                            Text("$quantidade tarefa(s) • ${projeto.cor}", color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { removerId = projeto.id }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Remover projeto ${projeto.nome}")
                        }
                    }
                }
            }
            item { androidx.compose.foundation.layout.Spacer(Modifier.padding(bottom = 72.dp)) }
        }
        FloatingActionButton(
            onClick = { mostrarFormulario = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Adicionar projeto")
        }
    }

    if (mostrarFormulario) {
        FormularioProjeto(
            projeto = null,
            aoSalvar = { nome, descricao, cor ->
                if (state.adicionarProjeto(nome, descricao, cor)) mostrarFormulario = false
            },
            aoCancelar = { mostrarFormulario = false }
        )
    }

    val projetoRemover = state.projetos.firstOrNull { it.id == removerId }
    if (projetoRemover != null) {
        ConfirmarRemocao(
            objeto = "projeto",
            mensagem = "As tarefas vinculadas serão mantidas, mas ficarão sem projeto.",
            aoConfirmar = {
                state.removerProjeto(projetoRemover.id)
                removerId = null
            },
            aoCancelar = { removerId = null }
        )
    }
}

@Composable
fun FormularioProjeto(
    projeto: Projeto?,
    aoSalvar: (String, String, String) -> Unit,
    aoCancelar: () -> Unit
) {
    var nome by remember(projeto?.id) { mutableStateOf(projeto?.nome.orEmpty()) }
    var descricao by remember(projeto?.id) { mutableStateOf(projeto?.descricao.orEmpty()) }
    var cor by remember(projeto?.id) { mutableStateOf(projeto?.cor ?: "Azul") }
    var coresAbertas by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = aoCancelar,
        title = { Text(if (projeto == null) "Novo projeto" else "Editar projeto") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 470.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text("Nome do projeto") },
                    isError = nome.isBlank(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = descricao,
                    onValueChange = { descricao = it },
                    label = { Text("Descrição") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Box {
                    OutlinedButton(onClick = { coresAbertas = true }) { Text("Cor: $cor") }
                    DropdownMenu(expanded = coresAbertas, onDismissRequest = { coresAbertas = false }) {
                        listOf("Azul", "Verde", "Violeta", "Laranja").forEach { opcao ->
                            DropdownMenuItem(text = { Text(opcao) }, onClick = {
                                cor = opcao
                                coresAbertas = false
                            })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = nome.isNotBlank(), onClick = { aoSalvar(nome, descricao, cor) }) {
                Text("Salvar")
            }
        },
        dismissButton = { TextButton(onClick = aoCancelar) { Text("Cancelar") } }
    )
}
