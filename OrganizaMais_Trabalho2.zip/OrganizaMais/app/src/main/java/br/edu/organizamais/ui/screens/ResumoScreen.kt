package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.ui.components.CabecalhoSecao
import br.edu.organizamais.ui.components.CartaoMetrica
import br.edu.organizamais.ui.components.EstadoVazio

@Composable
fun ResumoScreen(state: OrganizaState) {
    val total = state.tarefas.size
    val concluidas = state.tarefas.count { it.concluida }
    val pendentes = total - concluidas
    val percentual = if (total == 0) 0f else concluidas.toFloat() / total

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        CabecalhoSecao("Seu desempenho", "Os indicadores são atualizados a cada alteração nas listas.")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoMetrica("Concluídas", "$concluidas", Modifier.weight(1f))
            CartaoMetrica("Pendentes", "$pendentes", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoMetrica("Projetos", "${state.projetos.size}", Modifier.weight(1f))
            CartaoMetrica("Total", "$total", Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Progresso geral", fontWeight = FontWeight.SemiBold)
                Text("${(percentual * 100).toInt()}% das tarefas concluídas", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(progress = { percentual }, modifier = Modifier.fillMaxWidth())
            }
        }
        CabecalhoSecao("Progresso por projeto")
        if (state.projetos.isEmpty()) EstadoVazio("Cadastre projetos para acompanhar seus resultados.")
        state.projetos.forEach { projeto ->
            val tarefas = state.tarefasDoProjeto(projeto.id)
            val feitas = tarefas.count { it.concluida }
            val taxa = if (tarefas.isEmpty()) 0f else feitas.toFloat() / tarefas.size
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(projeto.nome, fontWeight = FontWeight.Bold)
                    Text("$feitas de ${tarefas.size} tarefa(s) concluída(s)")
                    LinearProgressIndicator(progress = { taxa }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
