package br.edu.organizamais.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightPalette = lightColorScheme(
    primary = Color(0xFF2556B6),
    onPrimary = Color.White,
    secondary = Color(0xFF007D72),
    background = Color(0xFFF6F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9EFF8)
)

private val DarkPalette = darkColorScheme(
    primary = Color(0xFFB2C5FF),
    secondary = Color(0xFF7AD8C8),
    background = Color(0xFF121820),
    surface = Color(0xFF1B2530)
)

@Composable
fun OrganizaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkPalette else LightPalette,
        content = content
    )
}
