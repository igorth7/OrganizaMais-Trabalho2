package br.edu.organizamais.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.edu.organizamais.ui.components.CabecalhoSecao

@Composable
fun SobreScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        CabecalhoSecao("Organiza+", "Aplicativo acadêmico de gerenciamento de tarefas e projetos.")
        Card {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Versão 1.0")
                Text("Desenvolvido com Kotlin, Jetpack Compose, Material 3 e Navigation Compose.")
                Text("Trabalho 2 — MAF: Mínimo Aplicativo Funcional.")
                Text("Os dados ficam em listas reativas na memória e são reiniciados ao encerrar o processo do aplicativo.")
            }
        }
    }
}
