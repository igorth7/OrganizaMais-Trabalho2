package br.edu.organizamais.navigation

object Routes {
    const val Inicio = "inicio"
    const val Tarefas = "tarefas"
    const val Projetos = "projetos"
    const val Resumo = "resumo"
    const val Ajuda = "ajuda"
    const val Sobre = "sobre"
    const val DetalheTarefa = "tarefa/{id}"
    const val DetalheProjeto = "projeto/{id}"

    fun tarefa(id: Int) = "tarefa/$id"
    fun projeto(id: Int) = "projeto/$id"
}
