package br.edu.organizamais

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.remember
import br.edu.organizamais.model.OrganizaState
import br.edu.organizamais.navigation.AppNavigation
import br.edu.organizamais.ui.theme.OrganizaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OrganizaTheme {
                val state = remember { OrganizaState() }
                AppNavigation(state)
            }
        }
    }
}
