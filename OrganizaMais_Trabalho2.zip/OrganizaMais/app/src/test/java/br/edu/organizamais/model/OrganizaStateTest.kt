package br.edu.organizamais.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrganizaStateTest {
    @Test
    fun adicionaProjetoComDadosValidos() {
        val state = OrganizaState()
        assertTrue(state.adicionarProjeto("Novo", "Descrição", "Azul"))
        assertTrue(state.projetos.any { it.nome == "Novo" })
    }

    @Test
    fun rejeitaCadastroSemTitulo() {
        val state = OrganizaState()
        assertFalse(state.adicionarTarefa("  ", "", null, "Alta"))
    }

    @Test
    fun alteraConclusaoDaTarefa() {
        val state = OrganizaState()
        val antes = state.tarefas.first { it.id == 1 }.concluida
        state.alternarConcluida(1)
        assertEquals(!antes, state.tarefas.first { it.id == 1 }.concluida)
    }

    @Test
    fun removerProjetoMantemTarefasSemAssociacao() {
        val state = OrganizaState()
        val quantidadeAntes = state.tarefas.size
        state.removerProjeto(1)
        assertEquals(quantidadeAntes, state.tarefas.size)
        assertNull(state.tarefas.first { it.id == 1 }.projetoId)
    }

    @Test
    fun atualizarTarefaPreservaConclusao() {
        val state = OrganizaState()
        state.alternarConcluida(1)
        assertTrue(state.atualizarTarefa(1, "Novo título", "Descrição", 2, "Baixa"))
        val tarefa = state.tarefas.first { it.id == 1 }
        assertEquals("Novo título", tarefa.titulo)
        assertTrue(tarefa.concluida)
    }

    @Test
    fun detalhesRelacionamProjetoETarefasCorretos() {
        val state = OrganizaState()
        val projeto = state.projetoDe(1)
        assertEquals("Faculdade", projeto?.nome)
        assertEquals(2, state.tarefasDoProjeto(1).size)
    }
}
