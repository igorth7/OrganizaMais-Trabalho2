# Matriz de conformidade com o enunciado

| Item exigido | Implementação | Situação no código |
| --- | --- | --- |
| Pelo menos 7 telas navegáveis | 8 destinos em `AppNavigation.kt` | Implementado |
| `NavHost` central | `AppNavigation.kt` | Implementado |
| Objeto de rotas com constantes | `Routes.kt` | Implementado |
| Navegação real de botões | `navController.navigate(...)` | Implementado |
| Barra de navegação inferior | `NavigationBar` e quatro destinos | Implementado |
| Barra superior e voltar | `TopAppBar` e `popBackStack()` | Implementado |
| 2 classes de dados diferentes | `Tarefa` e `Projeto` | Implementado |
| 2 telas de lista | `TarefasScreen.kt` e `ProjetosScreen.kt` | Implementado |
| `LazyColumn` e `Card` | Ambas as telas | Implementado |
| Listas reativas | `mutableStateListOf` em `OrganizaState.kt` | Implementado |
| Adicionar por formulário | `FormularioTarefa` e `FormularioProjeto` | Implementado |
| Remover pela interface | Ícones de lixeira e confirmação | Implementado |
| Marcar item | Checkbox de conclusão de tarefa | Implementado |
| 2 telas de detalhes | `TarefaDetalheScreen.kt` e `ProjetoDetalheScreen.kt` | Implementado |
| Passagem de dados reais | IDs de itens nas rotas | Implementado |
| Complexidade extra no detalhe | Progresso calculado e tarefas relacionadas no projeto | Implementado |
| Componentes variados | `Row`, `Column`, `Box`, `Scaffold`, botões, campos, checkboxes, menus | Implementado |
| README com instruções | `README.md` | Implementado |
| Documentação do processo | `PROCESSO_E_DECISOES.md` | Implementado, completar relatos reais da equipe |
| Capturas reais da execução | Pasta `prints/` | **Pendente: executar no Android Studio e capturar** |
| Projeto como continuação do Trabalho 1 | Código do Trabalho 1 não fornecido | **Pendente: comparar e integrar** |
| Novo repositório GitHub | Depende de conta do grupo | **Pendente: publicar** |
| Compilação e teste do app Android | Requer SDK, dependências e emulador | **Pendente: validar no Android Studio** |
