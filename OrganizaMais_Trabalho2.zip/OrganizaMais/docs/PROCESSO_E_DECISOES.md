# Processo de implementação e decisões — Organiza+

## Identificação

**Disciplina:** Desenvolvimento de Aplicativos Móveis  
**Atividade:** Trabalho 2 — MAF (Mínimo Aplicativo Funcional)  
**Integrantes:** preencher com os nomes reais do grupo  
**Repositório novo:** inserir o link depois da publicação

## 1. Ponto de partida e evolução

O Trabalho 2 pede a evolução de um aplicativo com três telas visuais para uma versão navegável com pelo menos sete telas e duas listas funcionais. A implementação fornecida neste pacote parte de três áreas principais — Início, Tarefas e Projetos — e adiciona Resumo, Detalhes da tarefa, Detalhes do projeto, Ajuda e Sobre.

**Limite de rastreabilidade:** o código do Trabalho 1 não foi disponibilizado durante a criação deste projeto. Portanto, não é possível afirmar que as três telas originais foram preservadas. Antes da entrega, o grupo deve comparar com o Trabalho 1, registrar diferenças reais e integrar o tema e as telas anteriores quando necessário.

**Evidência requerida:** anexar em `prints/` uma captura do Trabalho 1, se disponível, e capturas atuais das três telas principais.

## 2. Escolha das novas telas

- **Resumo:** apresenta dados agregados e atualiza indicadores de conclusão conforme as listas mudam.
- **Detalhe da tarefa:** recebe uma ID via navegação e consulta a tarefa correta para edição, mudança de estado e remoção.
- **Detalhe do projeto:** recebe uma ID, apresenta dados do projeto, calcula o percentual de conclusão e oferece acesso às tarefas vinculadas.
- **Ajuda:** documenta a utilização das ações principais dentro do próprio aplicativo.
- **Sobre:** reúne o escopo e as tecnologias utilizadas.

Essas telas têm funções efetivas e complementam as áreas de listagem. Os detalhes não são telas decorativas ou telas de login.

## 3. Organização do código

Foi escolhida a separação entre `model`, `navigation`, `ui/screens`, `ui/components` e `ui/theme`.

- `Models.kt`: define as duas `data class` principais, `Projeto` e `Tarefa`.
- `OrganizaState.kt`: mantém as coleções reativas e centraliza os métodos de adicionar, atualizar, remover e buscar.
- `Routes.kt`: define as rotas centralmente como constantes.
- `AppNavigation.kt`: reúne o `NavHost`, o `NavController`, a `NavigationBar` e a `TopAppBar`.
- `ui/screens`: mantém cada tela em seu arquivo.
- `ui/components`: reúne componentes reutilizáveis, como caixas informativas e confirmação de exclusão.

A separação facilita a leitura e permite alterar uma tela sem concentrar a lógica inteira na Activity.

## 4. Navegação e dados reais

A barra inferior oferece quatro destinos funcionais: Início, Tarefas, Projetos e Resumo. A navegação secundária usa rotas parametrizadas `tarefa/{id}` e `projeto/{id}`. O identificador da seleção é passado pelo `NavController`, recuperado na tela de destino e utilizado para procurar a instância correspondente na lista.

O botão de voltar da `TopAppBar` executa `popBackStack()`. As demais ações, como editar, concluir e remover, modificam os dados efetivos do aplicativo.

## 5. Listas, formulários e estado

As listas exibem cartões por meio de `LazyColumn` e `items`. Cada uma possui formulário de inclusão via `AlertDialog` e opção de remoção com confirmação. As tarefas incluem `Checkbox` para alternar o estado de conclusão. Os formulários possuem validação de título e seleção de valores utilizando menus suspensos.

O estado é compartilhado pelo objeto `OrganizaState`, instanciado no nível superior da composição. Assim, todas as telas enxergam as mesmas listas em memória.

## 6. Dificuldade adicional nos detalhes

O detalhe de projeto vai além de mostrar campos do objeto:

1. Busca tarefas cujo `projetoId` corresponde ao identificador do projeto aberto.
2. Calcula o número de tarefas vinculadas e quantas estão concluídas.
3. Calcula uma taxa `concluídas / total`, com proteção para listas vazias.
4. Exibe uma barra de progresso baseada nessa taxa.
5. Apresenta uma lista de tarefas relacionadas, com navegação para o detalhe da tarefa correta.

Essa complexidade foi escolhida porque associa as duas listas e evidencia uma regra de negócio real, em vez de apenas exibir valores fixos.

## 7. Decisões e limitações

- **Dados em memória:** alinhado à seção 5 do enunciado, que dispensa persistência nesta etapa.
- **Remoção segura:** apagar um projeto remove a associação, mas conserva suas tarefas.
- **Estilização:** componentes Material 3, contraste, cartões, espaçamento e cabeçalho consistente.
- **Validação:** não permite cadastrar projeto sem nome nem tarefa sem título.
- **Conteúdo inicial:** itens demonstrativos facilitam testar e apresentar os relacionamentos; todos podem ser editados ou apagados.

## 8. Dificuldades e resolução

A equipe deve registrar dificuldades efetivamente encontradas durante a execução no Android Studio, como problemas de dependência, ajustes de interface ou rotas incorretas. **Não foram inventados relatos de dificuldades de integrantes**. Após executar o projeto, registrar aqui: problema observado, causa encontrada, alteração aplicada e resultado.

## 9. Evidências obrigatórias

A documentação só atende completamente ao enunciado quando acompanhada de **capturas autênticas do app executando** ou vídeo curto. Os arquivos e os cenários necessários estão descritos em `REGISTRO_DE_EVIDENCIAS.md`. Não substituir por ilustrações ou telas fictícias.

## 10. Checklist de apresentação

Demonstrar navegação inferior, inclusão e remoção nas duas listas, abertura de dois detalhes diferentes, edição, alternância do checkbox e atualização do progresso no projeto e no resumo.
