# Roteiro de testes manuais

Marque cada cenário após executá-lo no emulador ou dispositivo Android.

- [ ] Iniciar o aplicativo sem travar e abrir Início.
- [ ] Alternar pelas abas Início, Tarefas, Projetos e Resumo.
- [ ] Criar projeto com nome, descrição e cor.
- [ ] Ver novo projeto na lista e abrir seus dados corretos.
- [ ] Editar o projeto e confirmar atualização na lista.
- [ ] Criar tarefa vinculada ao novo projeto.
- [ ] Criar tarefa sem projeto para verificar seleção opcional.
- [ ] Tentar salvar tarefa sem título e verificar que Salvar fica desabilitado.
- [ ] Confirmar que a lista mostra tarefas novas com título e prioridade corretos.
- [ ] Abrir o detalhe de uma tarefa e conferir seus dados.
- [ ] Editar a tarefa e confirmar a mudança na lista e no detalhe.
- [ ] Abrir o projeto a partir do detalhe da tarefa.
- [ ] Abrir uma tarefa a partir da lista de tarefas vinculadas do detalhe de projeto.
- [ ] Marcar uma tarefa como concluída na lista e verificar o indicador do projeto.
- [ ] Desmarcar uma tarefa no detalhe e verificar atualização no painel Resumo.
- [ ] Testar filtro de pendentes.
- [ ] Remover uma tarefa com confirmação; conferir que desaparece da lista e do painel.
- [ ] Cancelar uma tentativa de remoção e conferir que o item permanece.
- [ ] Remover um projeto e verificar que as tarefas sobrevivem como Sem projeto.
- [ ] Usar a seta de voltar na TopAppBar.
- [ ] Abrir Ajuda a partir de Início e Sobre a partir de Ajuda.
- [ ] Testar todos os botões e itens clicáveis restantes.
- [ ] Registrar capturas autênticas da execução nas etapas importantes.

## Testes automatizados

Executar `./gradlew :app:testDebugUnitTest` e guardar o resultado. Os testes cobrem alterações de dados e associações. Esse teste não substitui a inspeção das telas em emulador.
