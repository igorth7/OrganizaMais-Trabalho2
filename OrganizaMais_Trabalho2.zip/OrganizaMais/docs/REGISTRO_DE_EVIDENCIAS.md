# Registro de evidências visuais

O enunciado exige documentação com prints de tela ou vídeo do aplicativo **funcionando de verdade**. É necessário capturar os itens abaixo durante a execução no Android Studio ou em um aparelho.

| Arquivo sugerido em `prints/` | Conteúdo a registrar |
| --- | --- |
| `01-inicio.png` | Início e indicadores iniciais |
| `02-tarefas.png` | Lista de tarefas com vários itens |
| `03-cadastro-tarefa.png` | Formulário de cadastro de tarefa preenchido |
| `04-detalhe-tarefa.png` | Detalhe de uma tarefa cadastrada |
| `05-projetos.png` | Lista de projetos |
| `06-cadastro-projeto.png` | Formulário de cadastro de projeto |
| `07-detalhe-projeto.png` | Detalhe do projeto com tarefas e progresso |
| `08-resumo.png` | Resumo atualizado após marcar tarefas |
| `09-ajuda.png` | Guia de utilização |
| `10-sobre.png` | Informações sobre o aplicativo |
| `11-navegacao.png` | Captura com barra de navegação inferior |
| `12-trabalho1.png` | Uma tela do Trabalho 1, caso disponível, para documentar evolução |

O pacote preparado ainda **não contém capturas reais de execução**. Elas devem ser obtidas com o projeto rodando; não se devem apresentar protótipos como prova de funcionamento.

Após capturar, inserir os arquivos nesta pasta e conferir sua visualização no GitHub. Se preferir vídeo, registre a interação com as duas listas e a navegação.
